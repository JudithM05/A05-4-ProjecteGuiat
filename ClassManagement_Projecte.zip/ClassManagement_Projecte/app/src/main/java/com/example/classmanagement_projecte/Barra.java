package com.example.classmanagement_projecte;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.fragment.app.Fragment;

public class Barra extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflem el layout del fragment
        View rootView = inflater.inflate(R.layout.fragment_barra, container, false);

        // Obtener las referencias a los ImageButton
        ImageButton iconaHome = rootView.findViewById(R.id.iconaHome);
        ImageButton iconaAssistencia = rootView.findViewById(R.id.iconaAssistencia);
        ImageButton iconaEntrada = rootView.findViewById(R.id.iconaEntrada);
        ImageButton iconaSortida = rootView.findViewById(R.id.iconaSortida);
        ImageButton iconaPerfil = rootView.findViewById(R.id.iconaPerfil);
        ImageButton iconaAjustos = rootView.findViewById(R.id.iconaAjustos);

        // Configurar los listeners para cada ImageButton
        iconaHome.setOnClickListener(v -> {
            if (getActivity() != null) {
                Intent intent = new Intent(getActivity(), ActivityPantallaInici.class); // Cambia MainActivity a tu clase correspondiente
                startActivity(intent);
            }
        });

        iconaAssistencia.setOnClickListener(v -> {
            if (getActivity() != null) {
                Intent intent = new Intent(getActivity(), ActivityAssistenciaAlumne.class); // Cambia AssistenciaActivity a tu clase correspondiente
                startActivity(intent);
            }
        });

        iconaEntrada.setOnClickListener(v -> {
            if (getActivity() != null) {
                Intent intent = new Intent(getActivity(), ActivityRegistreEntrades.class); // Cambia EntradaActivity a tu clase correspondiente
                startActivity(intent);
            }
        });

        iconaSortida.setOnClickListener(v -> {
            if (getActivity() != null) {
                Intent intent = new Intent(getActivity(), ActivityRegistreSortides.class); // Cambia SortidaActivity a tu clase correspondiente
                startActivity(intent);
            }
        });

        iconaPerfil.setOnClickListener(v -> {
            if (getActivity() != null) {
                Intent intent = new Intent(getActivity(), ActivityPerfil.class); // Cambia PerfilActivity a tu clase correspondiente
                startActivity(intent);
            }
        });

        iconaAjustos.setOnClickListener(v -> {
            if (getActivity() != null) {
                Intent intent = new Intent(getActivity(), ActivityAjustos.class); // Cambia AjustosActivity a tu clase correspondiente
                startActivity(intent);
            }
        });

        return rootView;
    }
}
